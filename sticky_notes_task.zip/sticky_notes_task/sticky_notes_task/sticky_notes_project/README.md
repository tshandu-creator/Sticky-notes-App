# Sticky Notes

A simple Django CRUD application for creating, reading, updating, and
deleting sticky notes. Built for the Software Design practical task.

## Project structure

- `sticky_notes/` — Django project settings, root URL configuration.
- `notes/` — the app containing the `Note` model, views, forms, URLs,
  and templates for all CRUD operations.
- `templates/base.html` — shared base template extended by all pages.
- `static/css/style.css` — custom styling for the sticky-note card look.
- `diagrams/` — use case, sequence, and class diagrams for this app.
- `research_answers.md` — written answers for the research questions.

## Setup

```bash
python -m venv venv
source venv/bin/activate        # venv\Scripts\activate on Windows
pip install -r requirements.txt

python manage.py migrate
python manage.py collectstatic --noinput
python manage.py runserver
```

Then open http://127.0.0.1:8000/ in a browser.

## Features

- View all notes as a card grid (Read)
- Create a new note via a form (Create)
- View a single note's full content (Read)
- Edit an existing note's title and content (Update)
- Delete a note with a confirmation step (Delete)
