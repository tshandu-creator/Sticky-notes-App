# Research Answers

## 1. How HTTP applications preserve state across request-response cycles

HTTP is a stateless protocol: each request a browser sends is treated as an
entirely new, independent transaction, with no inherent memory of any
previous request from the same client. This creates a problem for
applications that need to recognise a returning user, such as remembering
that someone is logged in while they move between pages. To solve this,
servers issue a small unique identifier called a session ID, typically
stored as a cookie in the browser. On the first request (such as a login),
the server validates the user's credentials, creates a session record
(often stored server-side in a database or in-memory store), and sends the
session ID back to the browser inside a `Set-Cookie` header. The browser
then automatically attaches this cookie to every subsequent request to the
same domain. The server uses the cookie's session ID to look up the
matching session record and retrieve information about that user, such as
whether they are authenticated, without the user needing to log in again
on every page. Django implements this pattern through its sessions
framework, which stores session data in the database by default and
associates it with a `sessionid` cookie. Authentication state, such as
`request.user`, is then attached to each request based on that session
record, allowing the application to behave as though it "remembers" the
user across what are, technically, completely separate HTTP requests.

## 2. Performing Django database migrations to a server-based database like MariaDB

By default, a new Django project uses SQLite, a file-based database well
suited to development but not to production traffic. Moving to a
server-based relational database such as MariaDB involves several steps.
First, the `mysqlclient` Python package must be installed, since Django
communicates with MariaDB through the same client library used for MySQL.
Next, a MariaDB database and a dedicated database user with the
appropriate privileges must be created on the server, usually through the
MariaDB command-line client. In `settings.py`, the `DATABASES` dictionary
is then updated so its `ENGINE` points to
`django.db.backends.mysql`, with `NAME`, `USER`, `PASSWORD`, `HOST`, and
`PORT` filled in to match the new database's credentials and location;
these values are typically loaded from environment variables rather than
hard-coded, to avoid committing secrets to version control. Once the
connection settings are in place, running `python manage.py migrate`
applies all existing migration files against the new MariaDB database,
creating the necessary tables, indexes, and constraints from scratch. It
is worth noting that any existing data in the old SQLite database is not
automatically transferred; a separate data migration step, such as
exporting fixtures with `dumpdata` and reloading them with `loaddata`, is
required if existing records need to be preserved during the switch.

