from django import forms

from .models import Note


class NoteForm(forms.ModelForm):
    """Form used to create and edit a Note's title and content."""

    class Meta:
        model = Note
        fields = ["title", "content"]
        widgets = {
            "title": forms.TextInput(
                attrs={
                    "class": "form-control",
                    "placeholder": "Note title",
                }
            ),
            "content": forms.Textarea(
                attrs={
                    "class": "form-control",
                    "placeholder": "Write your note here...",
                    "rows": 6,
                }
            ),
        }
