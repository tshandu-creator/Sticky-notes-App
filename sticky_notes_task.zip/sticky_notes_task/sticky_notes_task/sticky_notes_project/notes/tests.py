"""
Unit tests for the Sticky Notes application.

These tests cover all five use cases identified in the use case diagram:
  - View Notes List
  - View Note Details
  - Create Note
  - Update Note
  - Delete Note

Tests are grouped into:
  - NoteModelTests:   the Note model itself
  - NoteFormTests:    the NoteForm validation rules
  - NoteViewTests:    each view, covering both GET and POST requests,
                       success paths, and failure / edge cases
"""

from django.test import TestCase
from django.urls import reverse

from .forms import NoteForm
from .models import Note


class NoteModelTests(TestCase):
    """Tests for the Note model itself."""

    def test_create_note_with_title_and_content(self):
        """A note can be created with a title and content."""
        note = Note.objects.create(title="Groceries", content="Milk, eggs, bread.")
        self.assertEqual(note.title, "Groceries")
        self.assertEqual(note.content, "Milk, eggs, bread.")

    def test_string_representation_returns_title(self):
        """__str__ should return the note's title for readability in admin/shell."""
        note = Note.objects.create(title="Call mom", content="Ask about the trip.")
        self.assertEqual(str(note), "Call mom")

    def test_created_at_and_updated_at_are_set_automatically(self):
        """Timestamps should be populated without the caller supplying them."""
        note = Note.objects.create(title="Timestamps", content="Check auto fields.")
        self.assertIsNotNone(note.created_at)
        self.assertIsNotNone(note.updated_at)

    def test_updated_at_changes_on_save(self):
        """Saving a note again should bump updated_at but not created_at."""
        note = Note.objects.create(title="Original", content="Initial content.")
        original_created = note.created_at
        original_updated = note.updated_at

        note.content = "Edited content."
        note.save()
        note.refresh_from_db()

        self.assertEqual(note.created_at, original_created)
        self.assertGreaterEqual(note.updated_at, original_updated)

    def test_notes_ordered_by_most_recently_updated_first(self):
        """Meta.ordering should return the most recently updated note first."""
        first = Note.objects.create(title="First", content="...")
        second = Note.objects.create(title="Second", content="...")
        notes = list(Note.objects.all())
        self.assertEqual(notes[0], second)
        self.assertEqual(notes[1], first)


class NoteFormTests(TestCase):
    """Tests for NoteForm validation rules."""

    def test_form_valid_with_title_and_content(self):
        form = NoteForm(data={"title": "Valid note", "content": "Some content."})
        self.assertTrue(form.is_valid())

    def test_form_invalid_when_title_missing(self):
        form = NoteForm(data={"title": "", "content": "Some content."})
        self.assertFalse(form.is_valid())
        self.assertIn("title", form.errors)

    def test_form_invalid_when_content_missing(self):
        form = NoteForm(data={"title": "Has a title", "content": ""})
        self.assertFalse(form.is_valid())
        self.assertIn("content", form.errors)

    def test_form_invalid_when_title_too_long(self):
        form = NoteForm(data={"title": "x" * 101, "content": "Some content."})
        self.assertFalse(form.is_valid())
        self.assertIn("title", form.errors)


class NoteViewTests(TestCase):
    """Tests for each CRUD view / use case."""

    def setUp(self):
        self.note = Note.objects.create(
            title="Existing note",
            content="Some existing content.",
        )

    # ---- Use case: View Notes List ----

    def test_note_list_returns_200_and_uses_correct_template(self):
        response = self.client.get(reverse("notes:note_list"))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, "notes/note_list.html")

    def test_note_list_shows_existing_notes(self):
        response = self.client.get(reverse("notes:note_list"))
        self.assertContains(response, "Existing note")

    def test_note_list_shows_empty_state_when_no_notes(self):
        Note.objects.all().delete()
        response = self.client.get(reverse("notes:note_list"))
        self.assertContains(response, "don't have any notes yet")

    # ---- Use case: View Note Details ----

    def test_note_detail_returns_200_for_existing_note(self):
        response = self.client.get(
            reverse("notes:note_detail", args=[self.note.pk])
        )
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Existing note")
        self.assertContains(response, "Some existing content.")

    def test_note_detail_returns_404_for_missing_note(self):
        response = self.client.get(reverse("notes:note_detail", args=[9999]))
        self.assertEqual(response.status_code, 404)

    # ---- Use case: Create Note ----

    def test_create_view_get_returns_empty_form(self):
        response = self.client.get(reverse("notes:note_create"))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, "notes/note_form.html")

    def test_create_view_post_valid_data_creates_note_and_redirects(self):
        count_before = Note.objects.count()
        response = self.client.post(
            reverse("notes:note_create"),
            data={"title": "New note", "content": "New content."},
        )
        self.assertRedirects(response, reverse("notes:note_list"))
        self.assertEqual(Note.objects.count(), count_before + 1)
        self.assertTrue(Note.objects.filter(title="New note").exists())

    def test_create_view_post_invalid_data_does_not_create_note(self):
        count_before = Note.objects.count()
        response = self.client.post(
            reverse("notes:note_create"),
            data={"title": "", "content": "Missing a title."},
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(Note.objects.count(), count_before)
        self.assertContains(response, "This field is required")

    # ---- Use case: Update Note ----

    def test_update_view_get_returns_form_prefilled_with_note_data(self):
        response = self.client.get(
            reverse("notes:note_update", args=[self.note.pk])
        )
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Existing note")

    def test_update_view_post_valid_data_updates_note_and_redirects(self):
        response = self.client.post(
            reverse("notes:note_update", args=[self.note.pk]),
            data={"title": "Updated title", "content": "Updated content."},
        )
        self.assertRedirects(
            response, reverse("notes:note_detail", args=[self.note.pk])
        )
        self.note.refresh_from_db()
        self.assertEqual(self.note.title, "Updated title")
        self.assertEqual(self.note.content, "Updated content.")

    def test_update_view_post_invalid_data_does_not_change_note(self):
        response = self.client.post(
            reverse("notes:note_update", args=[self.note.pk]),
            data={"title": "", "content": "Still no title."},
        )
        self.assertEqual(response.status_code, 200)
        self.note.refresh_from_db()
        self.assertEqual(self.note.title, "Existing note")

    def test_update_view_returns_404_for_missing_note(self):
        response = self.client.get(reverse("notes:note_update", args=[9999]))
        self.assertEqual(response.status_code, 404)

    # ---- Use case: Delete Note ----

    def test_delete_view_get_shows_confirmation_page(self):
        response = self.client.get(
            reverse("notes:note_delete", args=[self.note.pk])
        )
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, "notes/note_confirm_delete.html")
        self.assertContains(response, "Existing note")

    def test_delete_view_post_deletes_note_and_redirects(self):
        response = self.client.post(
            reverse("notes:note_delete", args=[self.note.pk])
        )
        self.assertRedirects(response, reverse("notes:note_list"))
        self.assertFalse(Note.objects.filter(pk=self.note.pk).exists())

    def test_delete_view_get_does_not_delete_note(self):
        """A GET request must only show the confirmation page, never delete."""
        self.client.get(reverse("notes:note_delete", args=[self.note.pk]))
        self.assertTrue(Note.objects.filter(pk=self.note.pk).exists())

    def test_delete_view_returns_404_for_missing_note(self):
        response = self.client.get(reverse("notes:note_delete", args=[9999]))
        self.assertEqual(response.status_code, 404)
