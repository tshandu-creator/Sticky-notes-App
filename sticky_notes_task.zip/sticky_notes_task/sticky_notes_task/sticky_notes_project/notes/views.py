from django.shortcuts import get_object_or_404, redirect, render

from .forms import NoteForm
from .models import Note


def note_list(request):
    """Display every sticky note, most recently updated first."""
    notes = Note.objects.all()
    return render(request, "notes/note_list.html", {"notes": notes})


def note_detail(request, pk):
    """Display the full title and content for a single note."""
    note = get_object_or_404(Note, pk=pk)
    return render(request, "notes/note_detail.html", {"note": note})


def note_create(request):
    """Create a new note from submitted form data."""
    if request.method == "POST":
        form = NoteForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("notes:note_list")
    else:
        form = NoteForm()
    return render(
        request,
        "notes/note_form.html",
        {"form": form, "title": "New note"},
    )


def note_update(request, pk):
    """Edit an existing note's title and/or content."""
    note = get_object_or_404(Note, pk=pk)
    if request.method == "POST":
        form = NoteForm(request.POST, instance=note)
        if form.is_valid():
            form.save()
            return redirect("notes:note_detail", pk=note.pk)
    else:
        form = NoteForm(instance=note)
    return render(
        request,
        "notes/note_form.html",
        {"form": form, "title": "Edit note"},
    )


def note_delete(request, pk):
    """Confirm and delete a note."""
    note = get_object_or_404(Note, pk=pk)
    if request.method == "POST":
        note.delete()
        return redirect("notes:note_list")
    return render(request, "notes/note_confirm_delete.html", {"note": note})
