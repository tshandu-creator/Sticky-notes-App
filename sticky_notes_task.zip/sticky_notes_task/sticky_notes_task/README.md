# Sticky Notes — Task Submission

This folder contains every component required for the Sticky Notes
practical task.

## Contents

- `diagrams/` — use case, sequence, and class diagrams for this app.
- `sticky_notes_project/` — the full Django project, including:
  - `notes/tests.py` — unit tests covering the model, the form, and
    all five use cases (list, detail, create, update, delete).
  - `notes/` — models, views, forms, URLs, and templates.
  - `diagrams/` — a copy of the same design diagrams, kept alongside
    the source so the GitHub repository is self-contained.
  - A local git repository, already initialised and committed, ready
    to be pushed to GitHub (see `sticky_github.txt`).
- `test_results.txt` — output of running `python manage.py test notes -v 2`,
  showing all 25 tests passing.
- `research_answers.md` — answers to the two research questions
  (HTTP state/session management, and Django migrations to MariaDB).
- `sticky_github.txt` — link to the GitHub repository for this project
  (see that file for setup instructions if the link is still a
  placeholder).

## Running the tests yourself

```bash
cd sticky_notes_project
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python manage.py migrate
python manage.py test notes -v 2
```

## Running the app yourself

```bash
python manage.py runserver
```

Then open http://127.0.0.1:8000/ in a browser.
